class maptile {

    constructor(){
        this.value = null;
        this.isHighlighted = false;
    }

}
